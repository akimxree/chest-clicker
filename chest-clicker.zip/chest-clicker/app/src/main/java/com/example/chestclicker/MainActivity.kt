package com.example.chestclicker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

data class Stats(
    val taps: Long = 0,
    val tokens: Long = 0,
    val totalGold: Long = 0,
    val bestStreak: Long = 0,
    val firstTapAt: Long? = null,
    val lastTapAt: Long? = null
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ChestClickerTheme { ChestScreen() } }
    }
}

@Composable
fun ChestClickerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1C1C1E),
            surface = Color(0xFFF7F7F9),
            onSurface = Color(0xFF1C1C1E)
        ),
        typography = Typography(displaySmall = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Light)),
        content = content
    )
}

@Composable
fun ChestScreen() {
    var stats by remember { mutableStateOf(Stats()) }
    var streak by remember { mutableStateOf(0L) }
    var tokenFlash by remember { mutableStateOf(false) }
    var particles by remember { mutableStateOf(0) }
    val infinite = rememberInfiniteTransition(label = "gold")
    val glow by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).systemBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(28.dp))
        Text("CHEST", fontSize = 13.sp, letterSpacing = 4.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f), fontWeight = FontWeight.Light)
        Spacer(Modifier.height(16.dp))

        // --- Статистика ---
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            StatRow("TAPS", stats.taps)
            StatRow("TOKENS", stats.tokens)
            StatRow("GOLD", stats.totalGold)
            StatRow("STREAK", streak)
            StatRow("BEST STREAK", stats.bestStreak)
            val rate = if (stats.taps > 0) stats.tokens.toDouble() / stats.taps else 0.0
            Text("TOKEN RATE  %.6f%%".format(rate * 100), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f), letterSpacing = 2.sp)
            Text("CHANCE  0.00073%", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f), letterSpacing = 2.sp)
        }

        Spacer(Modifier.weight(1f))

        // --- Сундук ---
        Box(Modifier.size(150.dp).clickable {
            val now = System.currentTimeMillis()
            val hit = Random.nextDouble() < 0.0000073
            val newTaps = stats.taps + 1
            val newTokens = if (hit) stats.tokens + 1 else stats.tokens
            val newGold = if (hit) stats.totalGold + 1000 else stats.totalGold
            val newStreak = if (hit) 0 else streak + 1
            stats = Stats(
                taps = newTaps,
                tokens = newTokens,
                totalGold = newGold,
                bestStreak = maxOf(stats.bestStreak, newStreak),
                firstTapAt = stats.firstTapAt ?: now,
                lastTapAt = now
            )
            streak = newStreak
            if (hit) {
                tokenFlash = true
                particles = 60
            }
        }.scale(if (tokenFlash) 1.18f else 1f),
            contentAlignment = Alignment.Center
        ) {
            // тело сундука
            Box(Modifier.matchParentSize().background(Color(0xFF2A2A2E), shape = CircleShape))
            // крышка — золотая полоса при токене
            Box(
                Modifier.matchParentSize().graphicsLayer { alpha = if (tokenFlash) glow else 0f }
                    .background(Color(0xFFFFD700), shape = CircleShape)
            )
            Text("📦", fontSize = 54.sp, modifier = Modifier.align(Alignment.Center))
            // партиклы: точки вокруг сундука при выпадении
            repeat(particles) { i ->
                val angle = (i * 6).toFloat()
                val r = 70 + (i % 5) * 12f
                Box(
                    Modifier
                        .size(6.dp)
                        .graphicsLayer {
                            translationX = (kotlin.math.cos(angle * kotlin.math.PI / 180f) * r).dp.toPx()
                            translationY = (kotlin.math.sin(angle * kotlin.math.PI / 180f) * r).dp.toPx()
                            alpha = if (tokenFlash) 1f else 0f
                        }
                        .background(Color(0xFFFFD700), shape = CircleShape)
                )
            }
        }

        if (tokenFlash) {
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(1400)
                tokenFlash = false
                particles = 0
            }
        }

        Spacer(Modifier.height(24.dp))
        Text(if (stats.tokens > 0) "⚓ TOKEN DROPPED — 1000 GOLD" else "tap the chest", fontSize = 12.sp, letterSpacing = 3.sp, color = Color(0xFFFFD700).copy(alpha = if (stats.tokens > 0) 1f else 0.35f))
        Spacer(Modifier.height(20.dp))

        // --- Сброс ---
        OutlinedButton(
            onClick = {
                stats = Stats()
                streak = 0
                tokenFlash = false
                particles = 0
            },
            modifier = Modifier.height(42.dp).widthIn(min = 160.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)),
            border = ButtonDefaults.outlinedButtonBorder(1.dp, MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f))
        ) { Text("RESET", fontSize = 12.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Light) }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
fun StatRow(label: String, value: Number) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 11.sp, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
        Text(value.toString(), fontSize = 11.sp, letterSpacing = 1.sp, color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Medium)
    }
}
